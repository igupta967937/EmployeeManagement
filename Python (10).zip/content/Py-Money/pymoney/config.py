class Config:
    SECRET_KEY = '562c8734de61f7d1cf886cb5aa0a197b'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    MAIL_SERVER = 'smtp.googlemail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'ishaan4newacc@gmail.com'  # Dummy Value
    MAIL_PASSWORD = 'ishaan883103665'  # Dummy Value